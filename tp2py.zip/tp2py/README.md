# Trabalho Prático II

## Como rodar

`python3 qlearning.py [inputfile] [modifier_id] x_i y_i n`

## OBS

É necessário ter *numpy* instalado no seu sistema para rodar o programa. Utilize o arquivo `requirements.txt` para criar um ambiente virtual
com tudo que você precisa.

# Relatório

O relatório do trabalho, em PDF, está disponível no diretório `report`, no arquivo `report.pdf`
